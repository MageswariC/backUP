$(document).ready(function(){ 
    var Drag = function(){
        var containerOffset;
        var containerWidth ;
        var containerHeight;
        var temp =0, index = 0;
        var imgWidth, imgHeight, imgeLoaded = 0, dragstarted = 0;   
        var lastMousePosition = {x:null, y:null}
        var index;
        var _this =this;
        var bayPosition = [{"top":"5", "left": "20"},{"top":"186", "left": "20"},{"top":"357", "left": "20"},{"top":"528", "left": "20"}]
        this.init = function(){            
            _this.getImgesize();
            _this.bindClick();          
        }
        this.bindClick = function(){         
            $('.pre').click(_this.preClick);
            $('.next').click(_this.nextClick);
            $('.hideObj').click(_this.hideObj);
            $('.close').click(_this.closeImg);
            $('.imgContainer').on('mousedown', _this.mouseDown);
            $('.imgContainer').on('mouseup', _this.mouseUp);
            $('.imgContainer').on('mousemove', _this.mouseMove);
        }
        this.getImgesize = function(){ 
            containerOffset = $('.imgContainer').offset();
            containerWidth = $('.imgContainer').outerWidth();
            containerHeight = $('.imgContainer').outerHeight();        
            imgWidth =$('.innerDiv').width();
            imgHeight = $('.innerDiv').height();
            imgeLoaded = 1;
        }       
        this.hideObj = function(){
            $('.innerDiv').css('pointer-events', 'none');
            var innerText = $(this).attr('data-text');
            $(this).remove();
            $('.overlay').removeClass('hideDiv').addClass('animate');
            $('.text').html('<img class = "treasure" src = "assets/images/treasure.png"></img><img class = "showImg" src = "assets/images/'+ innerText+'.jpg"/>');           
            $('.showImg').click(function(){
                $(this).animate({
                    left:"600px"
                });
            })            
            $('.treasure').click(function(){
                $(this).animate({
                    top:bayPosition[index].top,
                    left:bayPosition[index].left
                })
            })
        }
        this.closeImg = function(){ 
            $('.innerDiv').css('pointer-events', 'auto')
            console.log( $('.innerBay'+index+''), index)         
            $('.overlay').addClass('hideDiv').removeClass('animate');
           $('.innerBay'+index+'').append('<img class = "treasure" src = "assets/images/treasure.png"></img>')
           $('.treasure').addClass('bayposi');
           index++;
        }
        this.mouseDown = function(event){
            console.log('down')
            if(imgeLoaded == 1){
                dragstarted =1;
                lastMousePosition ={x:event.pageX - containerOffset.left, y:event.pageY - containerOffset.top}
            }
        }
        this.mouseUp = function(){
            dragstarted = 0;
        }
        this.mouseMove = function(event){
            console.log('move')
            if(dragstarted == 1){
                console.log(currentMousePosition, lastMousePosition)
                var currentMousePosition = {x:event.pageX - containerOffset.left, y:event.pageY - containerOffset.top};
                var changeX = currentMousePosition.x - lastMousePosition.x;
                var changeY = currentMousePosition.y - lastMousePosition.y;
                lastMousePosition = currentMousePosition;
                var imgLeft = parseInt($(".innerDiv").css('left'), 10);
                var imgTop = parseInt($(".innerDiv").css('top'), 10);
                var imgNewLeft = imgLeft+changeX;
                var imgNewTop = imgTop+changeY;
                if(imgNewLeft>0){
                    imgNewLeft = 0;
                }
                if(imgNewLeft<(containerWidth - imgWidth)){
                    imgNewLeft = containerWidth - imgWidth;
                }
                if(imgNewTop>0){
                    imgNewTop = 0;
                }
                if(imgNewTop<(containerHeight - imgHeight)){
                    imgNewTop = containerHeight - imgHeight;
                }
                $('.innerDiv').css({left: imgNewLeft + 'px', top: imgNewTop+'px'});
            }
        }
        this.preClick = function(){
            if(temp <= -1000) {
                temp = -1000;
            }else{
                temp = temp -100;
            }
           $('.innerDiv').animate({
                left:temp
           });
        }
        this.nextClick = function(){
            if(temp >= 0){
                temp =0;
            }else{
                temp = temp+100;
            }
           $('.innerDiv').animate({
                left:temp
           });
        }
    }

   var myDrag = new Drag();
    myDrag.init();
    $(window).resize(function(){       
        myDrag.getImgesize();
      });

})
