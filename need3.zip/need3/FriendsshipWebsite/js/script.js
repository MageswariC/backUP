/*slide show start*/
var slideImage = document.getElementsByClassName("slideImage");
var bullet =  document.getElementsByClassName("bullet");
for(var i=0; i<bullet.length; i++){
	(function(index){
	bullet[i].onclick = function(){
		changeImage(index);
	}
	})(i);
}
function changeImage(k){
	for(var i =0; i<slideImage.length; i++){
		slideImage[i].style.display = "none";
	}	
	slideImage[k].style.display = "block";
}
/*slide show end*/

/* lightbox start */
var getLightBoxImage = document.getElementsByClassName("gallery");
var getLightBoxDiv = document.getElementsByClassName("lightBox");
var getIcon = document.getElementsByClassName("closeIcon");
for(var i=0; i<getLightBoxImage.length; i++){
	(function(count){
		getLightBoxImage[i].onclick = function(){
		var getsrc = document.getElementsByClassName("lightBoxImg")[count].getAttribute("src");
		document.getElementById("appendImg").setAttribute("src", getsrc);
		getLightBoxDiv[0].style.display ="block";
	}
	}(i));

}
getIcon[0].onclick = function(){
	
		getLightBoxDiv[0].style.display ="none";
}
/* lightbox end*/
/* google map start*/
function myMap() {
	var myCenter = new google.maps.LatLng(8.430739,78.031063);
    var mapOptions = {        
        zoom: 10,
		center: myCenter,    }
var map = new google.maps.Map(document.getElementById("map"), mapOptions);
var marker = new google.maps.Marker({
	position:myCenter,
	animation: google.maps.Animation.BOUNCE
	});
marker.setMap(map);
}
/* google map end */

/* scroll start */
var getWelcome = document.getElementsByClassName("welcome")[0];
var getReadbtn = document.getElementsByClassName("readBtn")[0];
var getFrndStories = document.getElementsByClassName("frndStories")[0];
var getReadbtn1 = document.getElementsByClassName("readBtn1")[0];
var getGallery = document.getElementsByClassName("gallery1")[0];
var keepIn = document.getElementsByClassName("keepIn")[0];
var array = [getWelcome, getReadbtn, getFrndStories, getReadbtn1, getGallery, keepIn];
var array1 = ["animation", "animation1", "animation", "animation1"];
window.onscroll = function(){
	var a = document.getElementsByClassName("navContainer")[0];

document.getElementsByClassName("contentContainer")[0].classList.add("contentAni");
	var getScrollTop = document.body.scrollTop || document.documentElement.scrollTop;
	var windowHeight = document.body.scrollHeight || document.documentElement.scrollHeight;		
	if(a.offsetTop<getScrollTop){
		document.getElementsByClassName("innerMainNavContainer")[0].classList.add("fixed");
	}
	else{
		document.getElementsByClassName("innerMainNavContainer")[0].classList.remove("fixed");
	}
	var midPosition = (window.innerHeight/2 )+ getScrollTop;
	
	for(var i=0; i<array.length; i++){
		if(midPosition > array[i].getBoundingClientRect().top && midPosition < (array[i].getBoundingClientRect().top + array[i].getBoundingClientRect().bottom)){
			
			array[i].classList.add(array1[i]);
		}
	}
}
/* scroll end */