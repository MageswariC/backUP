window.onload = function() {
    var rotateBox = $('.rotateDiv');
    var arrowMove = $('.arrowMoveArea');
    var offset = rotateBox.offset();
    var mouseDown = false;
    var mouseUp = false;
    var degree;
    var x = 100;
    var imageLoaded =0;
    var y;
    var curdegree;
    var balloanImage = [{'src': 'balloon_oscillate_1_blue.gif', 'width':'200', 'height': '400', 'id': 'blueImg', 'class':'balloan', 'left':'0' },
                        {'src': 'balloon_oscillate_2_violet.gif', 'width':'200', 'height': '400', 'id': 'violetImg', 'class':'balloan', 'left':'100'},
                        {'src': 'balloon_oscillate_3_red.gif', 'width':'200', 'height': '400', 'id': 'redImg', 'class':'balloan', 'left':'200'},
                        {'src': 'balloon_oscillate_4_yellow.gif', 'width':'200', 'height': '400', 'id': 'yellowImg', 'class':'balloan', 'left':'300' },
                        {'src': 'balloon_oscillate_5_green.gif', 'width':'200', 'height': '400', 'id': 'greenImg', 'class':'balloan', 'left':'400' },
                        {'src': 'balloon_oscillate_6_bluishgreen.gif', 'width':'200', 'height': '400', 'id': 'bluishgreeImg', 'class':'balloan', 'left':'500' }];
                    
    function imageLoadedd(){
        for(var i = 0; i<balloanImage.length; i++ ){           
            var image = new Image();
            image.src = "assets/images/"+ balloanImage[i].src;
            image.width = balloanImage[i].width;
            image.height = balloanImage[i].height;
            image.id = balloanImage[i].id;
            $(image).css({left:''+balloanImage[i].left+'px'})
            $(image).addClass(''+balloanImage[i].class +'')
            image.onload = function(){
                imageLoaded++;
                if(imageLoaded == balloanImage.length){
                    arrowPart();
                }   
            }
            $('.imageContainer').append(image);
        }
             
    }
    imageLoadedd();

    function mouse(e) {        
        mouseUp = true;
        if (mouseDown == true) {
            var centerX = (offset.left) + (rotateBox.width() / 2);
            var centerY = (offset.top) + (rotateBox.height());
            var mouseX = e.pageX;
            var mouseY = e.pageY;
            var radians = Math.atan2(mouseX - centerX, mouseY - centerY);
            degree = (radians * (180 / Math.PI) * -1)+180;
            if (degree > 0 && degree < 20 || degree > 335 && degree < 360) {
                console.log('if  ' + degree);
                rotateBox.css('-moz-transform', 'rotate(' + degree + 'deg)');
                rotateBox.css('-webkit-transform', 'rotate(' + degree + 'deg)');
                rotateBox.css('-o-transform', 'rotate(' + degree + 'deg)');
                rotateBox.css('-ms-transform', 'rotate(' + degree + 'deg)');
                curdegree = degree;

            } else {
             
                
            }
        }
    }
    function arrowPart(){
        arrowMove.mousedown(function(e) {
            console.log('down')
            mouseDown = true;
            $(document).mousemove(mouse);
        })
        $(document).mouseup(function(e) {
            console.log('up')
           if(mouseUp == true){
           getDegree(curdegree);
           }        
            mouseDown = false;
        })
    }   

    function getDegree(getDegree) {
    // $('.arrow').hide();
        if (getDegree > 330 && getDegree < 340) { 
            console.log('hit')
            spriteAnimation('balloon_blast_1_blue.gif', 'blueImg');
            // setTimeout(function(){
            //     $('#blueImg').attr ('src', 'assets/images/balloon_blast_3_red.gif');  
            // }, 1000)
        } else if (getDegree > 340 && getDegree < 350) {
            spriteAnimation('balloon_blast_2_violet.gif', 'violetImg');
        } else if (getDegree > 350 && getDegree < 360) {
            spriteAnimation('balloon_blast_3_red.gif', 'redImg');
        } else if (getDegree > 0 && getDegree < 10) {
            spriteAnimation('balloon_blast_4_yellow.gif', 'yellowImg');
        } else if (getDegree > 10 && getDegree < 15) {
            spriteAnimation('balloon_blast_5_green.gif', 'greenImg');
        } else if (getDegree > 15 && getDegree < 20) {
            spriteAnimation('balloon_blast_6_bluishgreen.gif', 'bluishgreeImg');
        }
    }

    function spriteAnimation(img, id) {
        spriteSheet = new createjs.SpriteSheet({
            framerate: 24,
            "images": ["assets/images/1_bow_arrow_anim_straight.png"],
            "frames": {
                "regX": 0,
                "height": 760,
                "count": 78,
                "regY": 0,
                "width": 189
            },
            "animations": {
                start: [0, 77,true],
                stop: [0]
            }
        });
        stage = new createjs.Stage(document.getElementById("myCanvas"));
      
        curInstAnimation = new createjs.Sprite(spriteSheet);
        console.log(curInstAnimation);
        curInstAnimation.x = 0;
        curInstAnimation.y = 0;
        curInstAnimation.gotoAndStop('start');
        stage.addChild(curInstAnimation);
        createjs.Ticker.timingMode = createjs.Ticker.RAF;
        createjs.Ticker.addEventListener("tick", stage);
        createjs.Ticker.addEventListener("tick", function() {
            if (curInstAnimation.currentFrame >= 55) {
                // curInstAnimation1.gotoAndPlay('burst');
                curInstAnimation.gotoAndStop('stop');  
                $('#'+id+'').attr ('src', 'assets/images/'+img+'');
                setTimeout(function(){
                    $('#'+id+'').hide();
                }, 100)            
            }
        });
        // createjs.Ticker.addEventListener("tick", onEnterFrame);
        curInstAnimation.play();
    }

    function balloanBlast(){

    }
    // var stage1 = new createjs.Stage(document.getElementById("myCanvas1"));
    // createjs.Ticker.timingMode = createjs.Ticker.RAF;
    // for (var i = 0; i < 1; i++) {
    //     blueBalloonBurst(balloanArray[i], canvasPosition[i]);
    // }

    // function blueBalloonBurst(balloan, posi) {
    //     console.log(balloan, posi)
    //     let spriteSheet1 = new createjs.SpriteSheet({
    //         framerate: 24,
    //         "images": ['assets/images/' + balloan + ''],
    //         "frames": {
    //             "regX": 0,
    //             "height": 631,
    //             "count": 148,
    //             "regY": 0,
    //             "width": 340
    //         },
    //         "animations": {
    //             start: [0, 120],
    //             burst: [121, 148],
    //             stop: [138]
    //         }
    //     });

    //     //$('#canvas').attr('width', 633).attr('height', 688);            

    //     curInstAnimation1 = new createjs.Sprite(spriteSheet1);
    //     curInstAnimation1.x = posi;
    //     curInstAnimation1.y = 0;
    //     curInstAnimation1.gotoAndPlay('start');
    //     stage1.addChild(curInstAnimation1);
    //     stage1.update();
    //     createjs.Ticker.removeEventListener("tick", stage1);
    //     createjs.Ticker.addEventListener("tick", stage1);
    //     createjs.Ticker.addEventListener("tick", function() {
    //         if (curInstAnimation1.currentFrame >= 146) {
    //             curInstAnimation1.gotoAndStop('stop');

    //         }
    //     });
    // }
}