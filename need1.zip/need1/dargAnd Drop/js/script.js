$(document).ready(function() {
    alert();
    var drag, drop;
    var video = document.createElement("video");
    video.setAttribute("src", "assets/videos/F_Rot.mp4");
    video.load();

    var dragtop, dragleft, dragwidth, dragheight, parentel, zIndex, isvalid = false,
        resetArr = [],
        dragEl, count = 0;
        imgWidth = 0;
        imgHeight = 0;
    $.getJSON('assets/data/configuration.json', function(data) {

        $('.drop').each(function(key, val) {			
            $(this).data('position', data.data[key]);
			console.log(data.data[key])
        })
    })
    var dragObj = function(imgWidth, imgHeight){
		console.dir(dragObj);

        return {
            start: function() {
                dragtop = $(this).css('top');
                dragleft = $(this).css('left');
                dragwidth = $(this).css('width');
                dragheight = $(this).css('height')
                zIndex = $(this).data('zindex');
                parentel = $(this).parent();
                drag = $(this).data('ans');
                dragEl = $(this);
                zIndex = $('.drop[data-ans=' + drag + ']').data('zindex');
                $('.drop[data-ans=' + drag + ']').css('z-index', 11);
                $(this).css('z-index', zIndex);
            },

            cursorAt: {
                top: imgHeight / 2,
                left: imgWidth / 2
            },
            stop: function() {
                $('.drop[data-ans=' + drag + ']').css('z-index', zIndex);
                $(this).css({
                    'width': dragwidth,
                    'height': dragheight
                });
                drag = '';
                drop = '';
            },
            revert: function() {
                alert();
                if (!isvalid) {

                    $('.result').html('This is not a correct Place. Please see the Original Image.').css('color', 'red');
                    $(this).appendTo($(parentel).eq(0));
                    $(this).css({
                        'top': dragtop,
                        'left': dragleft
                    });
                    $(this).css({
                        'width': dragwidth,
                        'height': dragheight
                    });
                }
                isvalid = false;
            }
        }
    }

    for (var i = 0; i < $(".imgdrag").length; i++) {
        var imgWidth = $(".imgdrag").eq(i).width();
        var imgHeight = $(".imgdrag").eq(i).height();
        $(".imgdrag").eq(i).draggable(dragObj(imgWidth, imgHeight));

    }
    console.log($(".imgdrag"))
    $(".drop ").mousemove(function(e) {
        drop = $(this).data('ans');

    }).mouseup(function() {
        if (drag == drop) {
            $(".imgdrag[data-ans =" + drag + "]").css('border', 'none');
            count++;
            if (count <= $('.imgbox').length - 1) {
                $('.result').html('Correct!').css('color', 'green');
            } else {
                count = 0;
                $('.result').html('Activity End').css({
                    'color': 'black'
                });

                setTimeout(function() {
                    $('.axelBox, .imgdrag').css('display', 'none');
                    $('.videoContainer').css('display', 'block');
                    $('.videoContainer').html(video);
                    video.play();
                }, 800);

            }
            isvalid = true;
            $(dragEl).appendTo($(this));
            var style = $(this).data('position');
            $(dragEl).css(style);
            $(dragEl).draggable('disable');
        }
    });
    $('.reset').click(function() {
        for (var i = 0; i < 4; i++) {
            $('.imgdrag').css({
                'top': '0',
                'left': '0',
                'display': 'block',
                'border': '1px solid #00000040'
            });
            $('.axelBox').css('display', 'block')
            $('.videoContainer, .replaybtn, .reset').css('display', 'none');
            $('.result').html('');
            $('.imgdrag').draggable('enable');
            $(".imgbox").eq(i).html($('.img' + i + '')[0]);
            
        }
    });
    video.onended = function() {
        $('.replaybtn, .reset').css('display', 'block');
    }

    $('.replaybtn').click(function() {
        if (video.ended) {
            video.play();
        }

    });
});